ECE441 Lab 4 - LaTeX report

Main file: main.tex

Overleaf:
  Upload the complete ZIP as a new project.
  Select main.tex as the main document and compile with pdfLaTeX.

Local LaTeX:
  Keep figures/ beside main.tex.
  Run pdflatex main.tex twice to resolve references.
  XeLaTeX and Tectonic are also supported. Tectonic was used for verification.

The standalone .tex contains all prose, tables and bibliography entries.
Its eleven PNG figures are supplied in figures/. Download the complete ZIP to
compile the illustrated report outside the existing repository.

Before submission, complete the two remaining author entries near the top
of main.tex. The existing Laurence Yang author entry is retained.

Editing and data conventions:
  - Repeated explanations and speculative causal claims were shortened.
  - Extra all-channel plots and full statistics are in appendices.
  - The extended-window appendix includes run 2 C3/C4/O2 and pooled O2.
  - The final two appendices reproduce the statistical and analysis scripts
    as code screenshots, following the original report.
  - Original analysis values and images were retained. No EEG analysis was rerun.
  - The original permutation estimator b/1000 is described explicitly.
    Zero exceedances are displayed as 0/1000; they are not presented as an
    exact zero p-value or a demonstrated p < 0.001.
    In the run 2 extended-window figure, LaTeX replaces the original title
    strip so that O2 is labelled 0/1000; axes and waveform data are unchanged.
  - The proposed artefact-rejection and within-run permutation checks are
    future work, not analyses claimed to have been completed.

Source analysis and recordings:
  https://github.com/Echo078/ece441_lab4

Code screenshots:
  The code_screenshots/ directory contains 14 high-resolution PNGs.
  Exact copies of both source scripts are included in code/.
  Long lines wrap visually; source files are unchanged.
